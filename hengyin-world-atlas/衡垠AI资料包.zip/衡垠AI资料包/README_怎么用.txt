把本文件夹（或整个 ZIP）上传给 AI 即可。
AI 请先读 AI_START_HERE.md，再按 world-index.json 查编号，按 relationships.json 查关联。
不要把 status=proposed 的内容当作既定事实；不要把 coverage=index 的记录当作完整档案。
